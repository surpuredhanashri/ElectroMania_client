export class Otp {
    useremail: string = '';
  }