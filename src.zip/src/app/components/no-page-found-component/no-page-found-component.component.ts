import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-page-found-component',
  templateUrl: './no-page-found-component.component.html',
  styleUrls: ['./no-page-found-component.component.css']
})
export class NoPageFoundComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
